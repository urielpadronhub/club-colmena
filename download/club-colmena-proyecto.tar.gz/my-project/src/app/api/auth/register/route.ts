import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { createHash } from 'crypto'

// Función simple para hash de contraseñas
function simpleHash(text: string): string {
  return createHash('sha256').update(text).digest('hex')
}

// Generar número de afiliación único
async function generateAffiliationNumber(): Promise<string> {
  const year = new Date().getFullYear()
  let number: string
  let exists = true
  
  while (exists) {
    const random = Math.floor(Math.random() * 10000).toString().padStart(4, '0')
    number = `ABEJA-${random}-${year}`
    
    const existing = await db.bee.findUnique({
      where: { affiliationNumber: number }
    })
    exists = !!existing
  }
  
  return number!
}

// Generar código de regalo único
async function generateGiftCode(): Promise<string> {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'
  let code: string
  let exists = true
  
  while (exists) {
    code = 'MIEL-'
    for (let i = 0; i < 8; i++) {
      code += chars.charAt(Math.floor(Math.random() * chars.length))
    }
    
    const existing = await db.giftAction.findUnique({
      where: { giftCode: code }
    })
    exists = !!existing
  }
  
  return code!
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { 
      name, 
      email, 
      password, 
      cedula, 
      phone, 
      address, 
      birthDate,
      giftCode 
    } = body

    // Validaciones básicas
    if (!name || !email || !password || !cedula || !phone) {
      return NextResponse.json(
        { error: 'Faltan campos obligatorios: nombre, email, contraseña, cédula y teléfono son requeridos' },
        { status: 400 }
      )
    }

    // Verificar si el email ya existe
    const existingUser = await db.user.findUnique({
      where: { email }
    })

    if (existingUser) {
      return NextResponse.json(
        { error: 'El correo electrónico ya está registrado' },
        { status: 400 }
      )
    }

    // Verificar si la cédula ya existe
    const existingBee = await db.bee.findUnique({
      where: { cedula }
    })

    if (existingBee) {
      return NextResponse.json(
        { error: 'La cédula ya está registrada' },
        { status: 400 }
      )
    }

    // Crear el usuario
    const user = await db.user.create({
      data: {
        name,
        email,
        password: simpleHash(password),
        role: 'bee'
      }
    })

    // Generar número de afiliación
    const affiliationNumber = await generateAffiliationNumber()

    // Variables para el referido
    let referredByBeeId: string | null = null

    // Si viene con código de regalo, verificarlo
    if (giftCode) {
      const giftAction = await db.giftAction.findUnique({
        where: { giftCode },
        include: { giverBee: true }
      })

      if (giftAction && giftAction.status === 'available') {
        referredByBeeId = giftAction.giverBeeId
      }
    }

    // Crear la abeja
    const bee = await db.bee.create({
      data: {
        userId: user.id,
        cedula,
        phone,
        address: address || null,
        birthDate: birthDate ? new Date(birthDate) : null,
        affiliationNumber,
        referredByCode: giftCode || null,
        referredByBeeId,
        activationPaid: false,
        isActive: false
      }
    })

    // Si vino referido, crear registro de acción recibida
    if (giftCode && referredByBeeId) {
      // Actualizar el gift action
      await db.giftAction.update({
        where: { giftCode },
        data: {
          status: 'activated',
          receiverBeeId: bee.id,
          activatedAt: new Date()
        }
      })

      // Dar bonificación al que regaló
      await db.action.create({
        data: {
          beeId: referredByBeeId,
          type: 'bonus_referral',
          description: 'Bonificación por referido activado',
          quantity: 1,
          referenceId: giftCode
        }
      })
    }

    // Crear los 3 códigos de regalo para el nuevo socio
    const giftCodes = []
    for (let i = 0; i < 3; i++) {
      const code = await generateGiftCode()
      await db.giftAction.create({
        data: {
          giverBeeId: bee.id,
          giftCode: code,
          status: 'available'
        }
      })
      giftCodes.push(code)
    }

    // Crear el pago de activación pendiente
    await db.payment.create({
      data: {
        beeId: bee.id,
        type: 'activation',
        amount: 2.0,
        status: 'pending',
        dueDate: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000) // 7 días
      }
    })

    return NextResponse.json({
      success: true,
      message: 'Registro exitoso',
      data: {
        userId: user.id,
        beeId: bee.id,
        affiliationNumber: bee.affiliationNumber,
        giftCodes,
        requiresActivation: true
      }
    })

  } catch (error) {
    console.error('Error en registro:', error)
    return NextResponse.json(
      { error: 'Error interno del servidor' },
      { status: 500 }
    )
  }
}
